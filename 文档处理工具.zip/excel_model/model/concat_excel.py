from openpyxl import load_workbook, Workbook
import flet as ft
import os
import time

class ConcatExcel(ft.AlertDialog):
    get_infors_excel_path=ft.TextField(expand=True)
    get_infors_save_excel_path=ft.TextField(expand=True)

    def __init__(self,page):
        super().__init__()
        self.page=page
        self.content=ft.Container(
            expand=True,
            width=800,
            height=200,
            content=ft.Column(
                expand=True,
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("选择XLSX文件路径",width=150),
                            self.get_infors_excel_path,
                            ft.Button("选择",on_click=self.concat_excel_file_picker)
                        ]
                    ),
                    ft.Row(
                        controls=[
                            ft.Text("选择保存文件路径",width=150),
                            self.get_infors_save_excel_path,
                            ft.Button("选择",on_click=self.concat_excel_file_picker2)
                        ]
                    ),
                    ft.Container(
                        content=ft.FloatingActionButton(icon=ft.Icons.INFO,text="数据表合并",on_click=self.concat_excel_start),
                        alignment=ft.alignment.center
                    )
                ]
            )
        )
        self.title=ft.Text("批量数据表合并")

    def concat_excel_file_picker(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.get_infors_excel_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def concat_excel_file_picker2(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.get_infors_save_excel_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def concat_excel_start(self,e):
        source=self.get_infors_excel_path.value
        output_file = os.path.join(self.get_infors_save_excel_path.value,str(time.time())+".xlsx")
        self.merge_workbooks(source, output_file)
        self.word_down()



    def merge_workbooks(self,source_folder, output_file):
        merged_wb = Workbook()
        merged_wb.remove(merged_wb.active)
        for file in os.listdir(source_folder):
            if not file.endswith(('.xlsx')):
                continue
                
            src_wb = load_workbook(os.path.join(source_folder, file))
            for sheet in src_wb:
                new_sheet = merged_wb.create_sheet(
                    title=f"{file[:-5]}_{sheet.title}"
                )
                for row in sheet.iter_rows():
                    new_row = [cell.value for cell in row]
                    new_sheet.append(new_row)
                for col in sheet.columns:
                    new_sheet.column_dimensions[col[0].column_letter].width = sheet.column_dimensions[col[0].column_letter].width

        merged_wb.save(output_file)

    def word_down(self):
        self.page.open(
            ft.AlertDialog(
                title=ft.Text("操作完成")
            )
        )