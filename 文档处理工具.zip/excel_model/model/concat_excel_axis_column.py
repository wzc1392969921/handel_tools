import pandas as pd
import flet as ft
import os
import time

class ConcatExcelAxisColumn(ft.AlertDialog):
    get_infors_excel_path=ft.TextField(expand=True)
    get_infors_save_excel_path=ft.TextField(expand=True)

    def __init__(self,page):
        super().__init__()
        self.page=page
        self.content=ft.Container(
            expand=True,
            width=800,
            height=200,
            content=ft.Column(
                expand=True,
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("选择XLSX文件路径",width=150),
                            self.get_infors_excel_path,
                            ft.Button("选择",on_click=self.concat_excel_file_picker)
                        ]
                    ),
                    ft.Row(
                        controls=[
                            ft.Text("选择保存文件路径",width=150),
                            self.get_infors_save_excel_path,
                            ft.Button("选择",on_click=self.concat_excel_file_picker2)
                        ]
                    ),
                    ft.Container(
                        content=ft.FloatingActionButton(icon=ft.Icons.INFO,text="数据表合并",on_click=self.concat_excel_start),
                        alignment=ft.alignment.center
                    )
                ]
            )
        )
        self.title=ft.Text("批量数据表纵向合并")

    def concat_excel_file_picker(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.get_infors_excel_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def concat_excel_file_picker2(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.get_infors_save_excel_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def concat_excel_start(self,e):
        source=self.get_infors_excel_path.value
        output_file = os.path.join(self.get_infors_save_excel_path.value,str(time.time())+".xlsx")
        self.merge_workbooks(source, output_file)
        self.word_down()



    def merge_workbooks(self,source_folder, output_file):
        resu=[]
        for file in os.listdir(source_folder):
            if not file.endswith(('.xlsx')):
                continue
            path=os.path.join(source_folder, file)
            resu.append(pd.read_excel(path))
        pd.concat(resu,axis=0).to_excel(output_file,index=False)

    def word_down(self):
        self.page.open(
            ft.AlertDialog(
                title=ft.Text("操作完成")
            )
        )