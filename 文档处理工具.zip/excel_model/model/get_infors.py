import pandas as pd
import flet as ft
import os
import pyperclip

class GetInfors(ft.AlertDialog):
    get_infors_excel_path=ft.TextField(expand=True)

    def __init__(self,page):
        super().__init__()
        self.page=page
        self.content=ft.Container(
            expand=True,
            width=800,
            height=200,
            content=ft.Column(
                expand=True,
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("选择XLSX文件路径",width=150),
                            self.get_infors_excel_path,
                            ft.Button("选择",on_click=self.get_infors_file_picker)
                        ]
                    ),
                    ft.Container(
                        content=ft.FloatingActionButton(icon=ft.Icons.INFO,text="读取数据",on_click=self.get_infors_start),
                        alignment=ft.alignment.center
                    )
                ]
            )
        )
        self.title=ft.Text("批量合并")

    def get_infors_file_picker(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.get_infors_excel_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def get_infors_start(self,e):
        resu=[]
        for itms in os.listdir(self.get_infors_excel_path.value):
            if itms.endswith(".xlsx"):
                path = os.path.join(self.get_infors_excel_path.value,itms)
                df=pd.read_excel(path,sheet_name=None)
                for sheet_name in df.keys():
                    resu.append(
                        ft.ListTile(
                            title=ft.Text(itms+" "+sheet_name,text_align=ft.TextAlign.CENTER),
                            subtitle=ft.Row(controls=[ft.Text(str(df[sheet_name].describe()),text_align=ft.TextAlign.CENTER)],scroll=True,expand=True),
                            trailing=ft.PopupMenuButton(
                                icon=ft.Icons.MORE_VERT,
                                items=[
                                    ft.PopupMenuItem(text="复制内容",tooltip="复制内容到粘贴板",on_click=lambda e:pyperclip.copy(e.control.parent.parent.subtitle.controls[0].value)),
                                    ft.PopupMenuItem(text="复制文件路径",tooltip="复制文件路径",on_click=lambda e:pyperclip.copy(os.path.join(self.get_infors_excel_path.value,e.control.parent.parent.title.value.split(".xlsx")[0]+".xlsx")))
                                ],
                                tooltip="选项"
                            ),
                            
                        )
                    )
                

        r_dialog=ft.AlertDialog(
            content=ft.ListView(
                controls=resu,
                width=600
            )
        )
        self.page.open(r_dialog)
    
    def word_down(self):
        self.page.open(
            ft.AlertDialog(
                title=ft.Text("操作完成")
            )
        )