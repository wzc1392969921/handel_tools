import flet as ft
from docx import Document
from docxcompose.composer import Composer
import os
import time

class ConctWord(ft.AlertDialog):
    conct_word_docx_path=ft.TextField(expand=True)
    conct_word_pdf_path=ft.TextField(expand=True)

    def __init__(self,page):
        super().__init__()
        self.page=page
        self.content=ft.Container(
            expand=True,
            width=800,
            height=300,
            content=ft.Column(
                expand=True,
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("选择DOCX文件路径",width=150),
                            self.conct_word_docx_path,
                            ft.Button("选择",on_click=self.conct_word_file_picker_one)
                        ]
                    ),
                    ft.Row(
                        controls=[
                            ft.Text("选择保存路径",width=150),
                            self.conct_word_pdf_path,
                            ft.Button("选择",on_click=self.conct_word_file_picker_two)
                        ]
                    ),
                    ft.Container(
                        content=ft.FloatingActionButton(icon=ft.Icons.FIND_REPLACE,text="开始合并",on_click=self.conct_word_start),
                        alignment=ft.alignment.center
                    )
                ]
            )
        )
        self.title=ft.Text("批量合并")

    def conct_word_file_picker_one(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.conct_word_docx_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def conct_word_file_picker_two(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.conct_word_pdf_path.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def conct_word_start(self,e):
        src=self.conct_word_docx_path.value
        save = os.path.join(self.conct_word_pdf_path.value,str(time.time())+".docx")
        self.merge_with_page_break(src,save)

    def merge_with_page_break(self,input_folder, output_path):
        files = sorted([
            os.path.join(input_folder, f) 
            for f in os.listdir(input_folder) 
            if f.endswith('.docx')
        ])
        master = Document(files[0])
        master.add_page_break()
        composer = Composer(master)
        for file in files[1:]:
            doc = Document(file)
            doc.add_page_break()  
            composer.append(doc)
        composer.doc.paragraphs[-1]._element.getparent().remove(
            composer.doc.paragraphs[-1]._element
        )
        
        composer.save(output_path)
        self.word_down()

    def word_down(self):
        self.page.open(
            ft.AlertDialog(
                title=ft.Text("操作完成")
            )
        )