import flet as ft
from docx import Document
import os

class ReplaceAll(ft.AlertDialog):
    file_base_select=ft.TextField(expand=True)
    replace_all_file_replace_list_view=ft.ListView(expand=True,controls=[],spacing=10)
    replace_all_file_replace_list_str=ft.TextField(label="替换字符",expand=True)
    replace_all_file_replace_list_content=ft.TextField(label="替换内容",expand=True)

    def __init__(self,page):
        super().__init__()
        self.page=page
        self.content=ft.Container(
                expand=True,
                width=800,
                height=600,
                content=ft.Column(
                    expand=True,
                    controls=[
                        ft.Row(
                            controls=[
                                ft.Text("选择文件路径"),
                                self.file_base_select,
                                ft.Button("选择",on_click=self.replace_all_file_picker)
                            ]
                        ),
                        ft.Row(
                            # expand=True,
                            controls=[
                                ft.Text("添加替换内容"),
                                self.replace_all_file_replace_list_str,
                                self.replace_all_file_replace_list_content,
                                ft.Button("添加",on_click=self.replace_all_file_replace_list)
                            ]
                        ),
                        ft.Divider(height=3),
                        self.replace_all_file_replace_list_view,
                        ft.Container(
                            content=ft.FloatingActionButton(icon=ft.Icons.REDO_SHARP,text="开始替换",on_click=self.replace_all_start),
                            alignment=ft.alignment.center
                        )
                    ]
                )
            )
        self.title=ft.Text("批量替换")

    def replace_all_file_picker(self,e):
        def pick_files_result(e: ft.FilePickerResultEvent):
            self.file_base_select.value=e.path
            self.page.update()
        pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
        self.page.overlay.append(pick_files_dialog)
        self.page.update()
        pick_files_dialog.get_directory_path()

    def replace_all_file_replace_list(self,e):
        contents=ft.Row(expand=True,controls=[ft.TextField(label="替换字符",value=self.replace_all_file_replace_list_str.value,expand=True),ft.TextField(label="替换内容",value=self.replace_all_file_replace_list_content.value,expand=True),ft.Button("删除",on_click=self.replace_all_file_del_item)])
        self.replace_all_file_replace_list_view.controls.append(contents)
        self.page.update()

    def replace_all_file_del_item(self,e):
        self.replace_all_file_replace_list_view.controls.remove(e.control.parent)
        self.page.update()

    def replace_all_start(self,e):
        resu=[]
        for itms in self.replace_all_file_replace_list_view.controls:
            resu.append({
                "source":itms.controls[0].value,
                "dest":itms.controls[1].value
            })
        for itms in os.listdir(self.file_base_select.value):
            if itms.endswith(".docx"):
                path = os.path.join(self.file_base_select.value,itms)
                for contents in resu:
                    self.replace_word_content_with_format(path,contents["source"],contents["dest"])

    def replace_word_content_with_format(self,file_path, old_text, new_text):
        doc = Document(file_path)
        for paragraph in doc.paragraphs:
            for run in paragraph.runs:
                if old_text in run.text:
                    # 创建新的 Run 对象
                    new_run = run._element
                    new_run.text = run.text.replace(old_text, new_text)
                    # 复制原有格式
                    for key in run._r.attrib.keys():
                        if key!= 't':
                            new_run.attrib[key] = run._r.attrib[key]
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            if old_text in run.text:
                                # 创建新的 Run 对象
                                new_run = run._element
                                new_run.text = run.text.replace(old_text, new_text)
                                # 复制原有格式
                                for key in run._r.attrib.keys():
                                    if key!= 't':
                                        new_run.attrib[key] = run._r.attrib[key]
        doc.save(file_path)
        self.word_down()

    def word_down(self):
        self.page.open(
            ft.AlertDialog(
                content=ft.Text("操作完成")
            )
        )