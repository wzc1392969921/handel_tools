import flet as ft
import webbrowser
import random
from docx_model.model.replace_all import ReplaceAll as ReplaceAll
from docx_model.model.conct_word import ConctWord as ConctWord
from excel_model.model.get_infors import GetInfors as GetInfors
from excel_model.model.concat_excel import ConcatExcel as ConcatExcel
from excel_model.model.concat_excel_axis_row import ConcatExcelAxisRow as ConcatExcelAxisRow
from excel_model.model.concat_excel_axis_column import ConcatExcelAxisColumn as ConcatExcelAxisColumn

class page_word(ft.Container):
    def __init__(self,page):
        super().__init__()
        self.page=page
        self.expand=True
        self.content=ft.ListView(
            controls=[
                self.create_list("批量替换","在不修改word文件格式的情况下对指定文件夹下的文档内容进行批量替换",self.replace_all),
                self.create_list("批量合并","将指定文件夹下的word文档合并成单个文件",self.conct_word)
            ]
        )
    
    def create_list(self,tittle,detail,method):
        return ft.Card(
                    content=ft.Container(
                        content=ft.Column(
                            [
                                ft.ListTile(
                                    leading=ft.Icon(self.get_random_icon()),
                                    title=ft.Text(tittle),
                                    subtitle=ft.Text(detail),
                                    on_click=method
                                )
                            ]
                        ),
                        padding=10
                    )
                )
    
    def replace_all(self,e):
        self.page.open(ReplaceAll(self.page))
    
    def conct_word(self,e):
        self.page.open(ConctWord(self.page))

    def get_random_icon(self):
        all_icons = [icon for icon in dir(ft.Icons) if not icon.startswith("__")]
        random_icon = random.choice(all_icons)
        return getattr(ft.Icons, random_icon)




class page_excel(ft.Container):
    def __init__(self,page):
        super().__init__()
        self.page=page
        self.expand=True
        self.content=ft.ListView(
            controls=[
                self.create_list("获取信息","批量获取指定目录下的xls表格具体信息",self.get_infors),
                self.create_list("批量数据表合并","将指定文件夹下的xlsx表格的各个数据表合并成单个文件",self.concat_excel),
                self.create_list("批量数据表纵向合并","将指定文件夹下的xlsx表格中的首个数据表按照相同列合并成单个文件",self.concat_excel_axis_column),
                self.create_list("批量数据表横向合并","将指定文件夹下的xlsx表格中的首个数据表按照相同行合并成单个文件",self.concat_excel_axis_row)
            ]
        )
    
    def create_list(self,tittle,detail,method):
        return ft.Card(
                    content=ft.Container(
                        content=ft.Column(
                            [
                                ft.ListTile(
                                    leading=ft.Icon(self.get_random_icon()),
                                    title=ft.Text(tittle),
                                    subtitle=ft.Text(detail),
                                    on_click=method
                                )
                            ]
                        ),
                        padding=10
                    )
                )
    
    def get_infors(self,e):
        self.page.open(GetInfors(self.page))

    def concat_excel(self,e):
        self.page.open(ConcatExcel(self.page))

    def concat_excel_axis_row(self,e):
        self.page.open(ConcatExcelAxisRow(self.page))

    def concat_excel_axis_column(self,e):
        self.page.open(ConcatExcelAxisColumn(self.page))
    
    def get_random_icon(self):
        all_icons = [icon for icon in dir(ft.Icons) if not icon.startswith("__")]
        random_icon = random.choice(all_icons)
        return getattr(ft.Icons, random_icon)


class page_setting(ft.Container):
    def __init__(self,page):
        super().__init__()
        self.page=page
        self.expand=True
        self.content=ft.ListView(
            controls=[
                ft.Card(
                    content=ft.ListTile(
                            leading=ft.Image(src="https://i2.hdslb.com/bfs/face/13254a5d83f54feb5b6d47f5be3752e41db3c7a2.jpg@150w_150h.jpg"),
                            subtitle=ft.Text("数据批量处理工具"),
                            title=ft.Text("一键处理任何让你烦恼的数据！")
                    )
                ),
                self.create_list("访问作者B站主页","打开作者bilibili主页",self.goto_bilibili),
                self.create_list("访问作者CSDN主页","打开作者csdn主页",self.goto_csdn),
            ]
        )
    
    def create_list(self,tittle,detail,method):
        return ft.Card(
                    content=ft.Container(
                        content=ft.Column(
                            [
                                ft.ListTile(
                                    leading=ft.Icon(self.get_random_icon()),
                                    title=ft.Text(tittle),
                                    subtitle=ft.Text(detail),
                                    on_click=method
                                )
                            ]
                        ),
                        padding=10
                    )
                )
    
    def goto_bilibili(self,e):
        webbrowser.open("https://space.bilibili.com/1853174015")

    def goto_csdn(self,e):
        webbrowser.open("https://blog.csdn.net/qq_18741387")

    def get_random_icon(self):
        all_icons = [icon for icon in dir(ft.Icons) if not icon.startswith("__")]
        random_icon = random.choice(all_icons)
        return getattr(ft.Icons, random_icon)

class MainPage(ft.Container):
    def __init__(self,page):
        super().__init__()
        self.page=page
        self.expand=True
        rail=ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=100,
            min_extended_width=400,
            group_alignment=-0.9,
            destinations=[
                ft.NavigationRailDestination(
                    icon=ft.Icons.EDIT_DOCUMENT, 
                    selected_icon=ft.Icons.DOCUMENT_SCANNER, 
                    label="文档"
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icon(ft.Icons.TABLE_BAR),
                    selected_icon=ft.Icon(ft.Icons.TABLE_BAR_OUTLINED),
                    label="表格",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.SETTINGS_OUTLINED,
                    selected_icon=ft.Icon(ft.Icons.SETTINGS),
                    label="设置"
                ),
            ],
            on_change=self.on_clicks,
        )
        self.right_page=ft.Container(expand=True)
        self.right_page.content=page_word(self.page)
        self.content=ft.Row(
            [
                rail,
                ft.VerticalDivider(width=1),
                self.right_page
            ],
            expand=True
        )

    def on_clicks(self,e):
        index=e.control.selected_index
        if index==0:
            self.right_page.content=page_word(self.page)
        elif index==1:
            self.right_page.content=page_excel(self.page)
        elif index==2:
            self.right_page.content=page_setting(self.page)
        self.page.update()
        



def main(page):
    page.window.width=1920
    page.window.height=1080
    page.window.center()
    page.add(MainPage(page))


ft.app(main)



